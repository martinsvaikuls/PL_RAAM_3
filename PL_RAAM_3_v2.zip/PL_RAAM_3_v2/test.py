required_sheets = {
        "clients": ["id", "client_name", "email", "hash_password"],
        "printers": ["id", "model", "base_speed", "available_from"],
        "orders": ["id", "client_id", "shirt_size", "base_color", "attachment", "quantity", "status", "created_at"],
        "fulfillment_plan": ["id", "order_id", "printer_id", "start_time", "end_time", "cost", "client_cost"],
        "meta": ["key", "value"]
    }

for sheet_name, columns in required_sheets.items():
    # Now sheet_name will hold the key (e.g., "clients", "printers")
    # and columns will hold the list of columns (e.g., ["id", "client_name", "email", "hash_password"])
    # You can now use these variables inside your loop
    print(sheet_name, columns)